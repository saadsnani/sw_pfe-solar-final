# 📱 كيفاش دير APK و تشوفو ف التليفون - Guide Sahl

## 🎯 اش بغيتي دير

بغيتي تاخد الموقع ديالك و تحولو ل APK و تشوفو ف التليفون ديالك!

---

## ⚠️ المشكل لي عندك دابا

**الشبكة ديالك كاتمنع التحميل من npm**

قبل ما تبدا، خاصك تحل هاد المشكل:

### ✅ الحل السريع (5 دقايق):

```
1. دير Hotspot ف التليفون ديالك
2. وصل الكمبيوتر مع الHotspot
3. دير هاد الCommand:
   npm install @capacitor/core @capacitor/cli @capacitor/android
4. تسنى حتى يكمل التنزيل (3-5 دقايق)
```

---

## 📱 من بعد، خطوات باش تدير APK

### الطريقة 1: Automatique (سهل بزاف)

```batch
REM دوبل كليك على هاد الملف:
setup-mobile.bat

REM تسنى 10 دقايق، غادي يدير كولشي
```

---

### الطريقة 2: Manual (خطوة بخطوة)

#### الخطوة 1: نصب Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
```

#### الخطوة 2: بني الموقع
```bash
npm run build
```

#### الخطوة 3: زيد Android
```bash
npx cap add android
```

#### الخطوة 4: Sync الملفات
```bash
npx cap sync android
```

#### الخطوة 5: حل Android Studio
```bash
npm run mobile:open
```

#### الخطوة 6: دير Run ف Android Studio
- كليك على الزر الخضر ▶️ "Run"
- تسنى 2-3 دقايق
- غادي تشوف الApp كتخدم!

#### الخطوة 7: دير APK File
ف Android Studio:
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

---

## 📂 فين غادي تلقى APK

```
android\app\build\outputs\apk\debug\app-debug.apk
```

---

## 📱 كيفاش تنصبو ف التليفون

### الطريقة 1: USB Cable

```
1. وصل التليفون مع الكمبيوتر ب USB
2. كوبي الملف: app-debug.apk
3. بيستيه ف التليفون
4. دوبل كليك عليه ف التليفون
5. كليك "Install"
6. VOILA! ✅
```

### الطريقة 2: Bluetooth

```
1. سيفط الAPK ب Bluetooth
2. قبلو ف التليفون
3. حل الملف
4. كليك "Install"
```

### الطريقة 3: WhatsApp/Email

```
1. سيفط لراسك الAPK ب WhatsApp
2. حل الرسالة ف التليفون
3. تيليشارجي الملف
4. حلو و نصبو
```

---

## ⚠️ إلا ما بغاش ينصب

### Problem: "Can't install from unknown sources"

**Solution:**
```
1. Settings → Security
2. Enable "Unknown sources" أو "Install unknown apps"
3. عاود حاول
```

---

## 🎯 الخطوات كاملين ف صورة واحدة

```
┌─────────────────────────────────────┐
│ 1. حل مشكل Network                  │
│    → استعمل Hotspot ديال التليفون   │
└─────────────┬───────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│ 2. نصب Capacitor                    │
│    → npm install @capacitor/...     │
└─────────────┬───────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│ 3. دير Setup                        │
│    → setup-mobile.bat               │
└─────────────┬───────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│ 4. حل Android Studio                │
│    → npm run mobile:open            │
└─────────────┬───────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│ 5. Build APK                        │
│    → Build → Build APK              │
└─────────────┬───────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│ 6. سيفط APK للتليفون                │
│    → USB / Bluetooth / WhatsApp     │
└─────────────┬───────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│ 7. نصبو ف التليفون                  │
│    → Install → VOILA! ✅            │
└─────────────────────────────────────┘
```

---

## ⏱️ الوقت لي غادي تاخد

| الخطوة | المرة الأولى | المرات الجاية |
|--------|--------------|---------------|
| نصب Android Studio | 30-60 دقيقة | - |
| نصب Capacitor | 5 دقايق | - |
| Build أول مرة | 10 دقايق | 2-3 دقايق |
| تسيفط و تنصب ف التليفون | 5 دقايق | 2 دقايق |

**المجموع أول مرة: ~1 ساعة**

---

## 💡 نصائح مهمة

### ✅ استعمل Hotspot
- الحل الأسرع للمشكل ديال Network
- كاتخدم 95% من الوقت

### ✅ تسنى Gradle Sync
- أول مرة كاياخد 10-15 دقيقة
- ما تسدش Android Studio!

### ✅ شوف Logcat
- إلا كان شي مشكل
- Android Studio → Logcat
- غادي تشوف الErrors هناك

---

## 🔥 الطريقة الأسرع (TL;DR)

```bash
# 1. حل مشكل Network (استعمل Hotspot!)
# تليفون → Settings → Hotspot → ON
# كمبيوتر → وصل مع Hotspot

# 2. نصب Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 3. دير كولشي Automatique
setup-mobile.bat

# 4. تسنى 10 دقايق
# ☕ شرب قهوة!

# 5. حل Android Studio
npm run mobile:open

# 6. Build APK
# ف Android Studio: Build → Build APK

# 7. الAPK فهنا:
# android\app\build\outputs\apk\debug\app-debug.apk

# 8. سيفطو للتليفون و نصبو!
# VOILA! 🎉
```

---

## 📞 إلا بغيتي مساعدة

### المشكل: Network ما كايخدمش
**الحل:** TROUBLESHOOTING_NETWORK.md

### المشكل: Build فشل
**الحل:** شوف Logcat ف Android Studio

### المشكل: APK ما كينصبش
**الحل:** Settings → Security → Unknown sources → ON

---

## 🎊 من بعد ما يكمل

غادي يكون عندك:
- ✅ APK File جاهز
- ✅ App كتخدم ف التليفون
- ✅ يمكن تسيفطو لصحابك
- ✅ يمكن تحطو ف Play Store

---

## 🇲🇦 بالدارجة المغربية

**الخلاصة:**
1. دير Hotspot → حل المشكل
2. دير `setup-mobile.bat` → يدير كولشي
3. حل Android Studio → Build APK
4. سيفط APK للتليفون → نصبو
5. BINGO! 🎉

**الوقت:** 1 ساعة أول مرة، 5 دقايق من بعد

**المشكل الوحيد:** Network (حلو ب Hotspot)

---

## 📱 Commands سريعة (Copy-Paste)

```powershell
# كولشي ف Command واحد:
npm install @capacitor/core @capacitor/cli @capacitor/android && npm run build && npx cap add android && npx cap sync android && npm run mobile:open

# أو بسيط:
setup-mobile.bat
```

---

**بصحة! (Good luck!) 🚀📱**

**إلا عندك شي سؤال، سوليني! 💬**
