"use client"

import { BatteryTemperatureTestPage } from "@/components/battery-temperature-test-page"

export default function Page() {
  return <BatteryTemperatureTestPage />
}
